export default function adminPage(){
    return (
        <div>
            <h1>Админка</h1>
        </div>
    );
}